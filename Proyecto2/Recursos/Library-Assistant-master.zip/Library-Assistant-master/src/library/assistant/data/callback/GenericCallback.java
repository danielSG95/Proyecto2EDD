package library.assistant.data.callback;

/**
 *
 * @author afsal.villan
 */
public interface GenericCallback {

    Object taskCompleted(Object val);
}
